a=b("ola")
c(a)
d=e(a)+a
z(f,a)

# tip: sanitization can only occur if it intercepts a vulnerability
