a=b(boo)
k=0
if (c == a) :
   d="xpto1"
else :
   d="xpto2"
e(d,"koneksi")

# tip: conditionals can encode implicit flows
