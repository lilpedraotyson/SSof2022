a=b("ola")
c=d("oi",e(f(a)),a)
e(c)

# tip: function calls can be nested, can have both tainted and untainted arguments, and sources and sanitizers might appear in the arguments
