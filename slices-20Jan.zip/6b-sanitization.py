a=b()
b=c(33)
d=e(a,b)

# tip: relative order of sources, sanitizers and sinks, matters
